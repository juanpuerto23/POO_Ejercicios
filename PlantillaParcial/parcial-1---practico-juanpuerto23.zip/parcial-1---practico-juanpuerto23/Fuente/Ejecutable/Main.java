package Fuente.Ejecutable;

import Fuente.Controlador.controlador;
import Fuente.Modelo.Modelo;
import Fuente.Vista.VentanaPrincipal;

public class Main 
{
    public static void main(String[] args) 
    {
        VentanaPrincipal miVentanaPrincipal = new VentanaPrincipal();
        Modelo miModelo = null;
        controlador miControlador = new controlador(miVentanaPrincipal, miModelo);
    }
}
package Fuente.Controlador;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import Fuente.Modelo.Modelo;
import Fuente.Vista.VentanaPrincipal;

public class controlador implements ActionListener
{
    //----------------------------
    //Atributos
    //----------------------------
    private VentanaPrincipal venPrin;
    private Modelo model;
    
    //----------------------------
    //Metodos
    //----------------------------
    
    //Constructor
    public controlador(VentanaPrincipal pVenPrin, Modelo pModel)
    {
        this.venPrin = pVenPrin;
        this.model = pModel;
        this.venPrin.miPanelOperaciones.agregarOyentesBotones(this);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) 
    {
        //Identificar el comendo generado (calcular, borrar, salir)
        String comando = ae.getActionCommand();
        
        if(comando.equals("crear"))
        {   
            //Validar datos entrada
            try
            {
                //Creación del objeto tipo Carro
                model = new Modelo(null, null, null);
                venPrin.miPanelResultado.mostrarResultado("Ahora puede ingresar datos");
                //Desactivar boton crear
                venPrin.miPanelOperaciones.desactivarBotonCrear();
                //Activar botones
                venPrin.miPanelOperaciones.activarBotones();
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Error en datos de entrada", "Error", JOptionPane.ERROR_MESSAGE);
            }   
        }
        
        if(comando.equals("vectorA"))
        {   
            venPrin.crearDialogoIngresarDatosA();
            this.venPrin.miDialogoIngresarDatosA.agregarOyentesBotones(this);
        }
        
        if(comando.equals("vectorB"))
        {   
            venPrin.crearDialogoIngresarDatosB();
            this.venPrin.miDialogoIngresarDatosA.agregarOyentesBotones(this);
        }

        if(comando.equals("aceptarA"))
        {
            int VectorA[];
            VectorA = new int [5];
            int VectorA1 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA1());
            int VectorA2 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA2());
            int VectorA3 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA3());
            int VectorA4 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA4());
            int VectorA5 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA5());
            VectorA[0] = VectorA1;
            VectorA[1] = VectorA2;
            VectorA[2] = VectorA3;
            VectorA[3] = VectorA4;
            VectorA[4] = VectorA5;
            venPrin.miPanelResultado.mostrarResultado("\nSe han creado datos en el vector A: " + "\n1) " + VectorA1 + "\n2) " + VectorA2 + "\n3) " + VectorA3 + "\n4) " + VectorA4 + "\n5) " + VectorA5);
            venPrin.miDialogoIngresarDatosA.cerrarDialogoA();
        }
        
        if(comando.equals("aceptarB"))
        {
            int VectorB[];
            VectorB = new int [5];
            int VectorB1 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB1());
            int VectorB2 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB2());
            int VectorB3 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB3());
            int VectorB4 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB4());
            int VectorB5 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB5());
            VectorB[0] = VectorB1;
            VectorB[1] = VectorB2;
            VectorB[2] = VectorB3;
            VectorB[3] = VectorB4;
            VectorB[4] = VectorB5;
            venPrin.miPanelResultado.mostrarResultado("\nSe han creado datos en el vector B: " + "\n1) " + VectorB1 + "\n2) " + VectorB2 + "\n3) " + VectorB3 + "\n4) " + VectorB4 + "\n5) " + VectorB5);
            venPrin.miDialogoIngresarDatosB.cerrarDialogoB();
        }
        
        if(comando.equals("calcular"))
        {
            int VectorC[];
            boolean bandera1 = false;
            boolean bandera2 = false;
            boolean bandera3 = false;
            boolean bandera4 = false;
            boolean bandera5 = false;

            int VectorA1 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA1());
            int VectorA2 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA2());
            int VectorA3 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA3());
            int VectorA4 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA4());
            int VectorA5 = Integer.parseInt(venPrin.miDialogoIngresarDatosA.getVectorA5());

            int VectorB1 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB1());
            int VectorB2 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB2());
            int VectorB3 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB3());
            int VectorB4 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB4());
            int VectorB5 = Integer.parseInt(venPrin.miDialogoIngresarDatosB.getVectorB5());

            if(VectorA1 == VectorB1 || VectorA1 == VectorB2 || VectorA1 == VectorB3 || VectorA1 == VectorB4 || VectorA1 == VectorB5)
            {
                bandera1 = true;
            }

            if(VectorA2 == VectorB1 || VectorA2 == VectorB2 || VectorA2 == VectorB3 || VectorA2 == VectorB4 || VectorA2 == VectorB5)
            {
                bandera2 = true;
            }

            if(VectorA3 == VectorB1 || VectorA3 == VectorB2 || VectorA3 == VectorB3 || VectorA3 == VectorB4 || VectorA3 == VectorB5)
            {
                bandera3 = true;
            }

            if(VectorA4 == VectorB1 || VectorA4 == VectorB2 || VectorA4 == VectorB3 || VectorA4 == VectorB4 || VectorA4 == VectorB5)
            {
                bandera4 = true;
            }

            if(VectorA5 == VectorB1 || VectorA5 == VectorB2 || VectorA5 == VectorB3 || VectorA5 == VectorB4 || VectorA5 == VectorB5)
            {
                bandera5 = true;
            }

            VectorC = new int [5];
            
            if(bandera1 == true)
            {
                VectorC[0] = VectorA1;
            }

            if(bandera1 == false)
            {
                VectorC[0] = 0;
            }

            if(bandera2 == true)
            {
                VectorC[1] = VectorA2;
            }

            if(bandera2 == false)
            {
                VectorC[1] = 0;
            }
            
            if(bandera3 == true)
            {
                VectorC[2] = VectorA3;
            }
            
            if(bandera3 == false)
            {
                VectorC[2] = 0;
            }

            if(bandera4 == true)
            {
                VectorC[3] = VectorA4;
            }

            if(bandera4 == false)
            {
                VectorC[3] = 0;
            }
            
            if(bandera5 == true)
            {
                VectorC[4] = VectorA5;
            }

            if(bandera5 == false)
            {
                VectorC[4] = 0;
            }
            
            venPrin.miPanelResultado.mostrarResultado("Vector C: \n" + VectorC[0] + "\n" + VectorC[1] + "\n" + VectorC[2] +"\n"+ VectorC[3] +"\n"+ VectorC[4]);
        }
    }    
}
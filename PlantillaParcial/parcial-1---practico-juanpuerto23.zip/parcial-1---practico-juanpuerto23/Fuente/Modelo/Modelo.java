package Fuente.Modelo;

public class Modelo 
{
    private int VectorA[];
    private int VectorB[];
    private int VectorC[];

    public Modelo(int[] pVectorA, int[] pVectorB, int[] pVectorC)
    {
        this.VectorA = pVectorA;
        this.VectorB = pVectorB;
        this.VectorC = pVectorC;
    }

    public int[] getVectorA() 
    {
        return VectorA;
    }

    public void setVectorA(int[] vectorA) 
    {
        VectorA = vectorA;
    }

    public int[] getVectorB() 
    {
        return VectorB;
    }

    public void setVectorB(int[] vectorB) 
    {
        VectorB = vectorB;
    }

    public int[] getVectorC() 
    {
        return VectorC;
    }

    public void setVectorC(int[] vectorC) 
    {
        VectorC = vectorC;
    }

    
}

package Fuente.Vista;

import javax.swing.*;

public class VentanaPrincipal extends JFrame
{
    public PanelEntradaDatos miPanelEntradaDatos;
    public PanelOperaciones miPanelOperaciones;
    public PanelResultados miPanelResultado;
    public DialogoIngresarDatosA miDialogoIngresarDatosA;
    public DialogoIngresarDatosB miDialogoIngresarDatosB;

    //-------------------------
    //Métodos
    //-------------------------
    
    //Metodo constructor
    public VentanaPrincipal()
    {
        
        //Definición del contenedor de la ventana
        setLayout(null);
        
        
        //Creación y adición del PanelEntradaDatos
        miPanelEntradaDatos = new PanelEntradaDatos();
        miPanelEntradaDatos.setBounds(10,10,560,390);
        add(miPanelEntradaDatos);
       
        
        //Creación y adición del PanelOperaciones
        miPanelOperaciones = new PanelOperaciones();
        miPanelOperaciones.setBounds(10,400,560,60);
        add(miPanelOperaciones);
        
        //Creación y adición del PanelOperaciones
        miPanelResultado = new PanelResultados();
        miPanelResultado.setBounds(10,470,560,200);
        add(miPanelResultado);

        miDialogoIngresarDatosA = null;

        miDialogoIngresarDatosB = null;
        
        //Caracteristicas de la ventana
        setTitle("ARRAIIIIIIID");
        setSize(600,800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }

    public void crearDialogoIngresarDatosA()
    {
        miDialogoIngresarDatosA = new DialogoIngresarDatosA();
    }

    public void crearDialogoIngresarDatosB()
    {
        miDialogoIngresarDatosB = new DialogoIngresarDatosB();
    }
}

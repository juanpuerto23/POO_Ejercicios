package Fuente.Vista;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

public class DialogoIngresarDatosB extends JDialog 
{
    private JLabel lbTitulo;
    private JLabel lbVectorB1;
    private JLabel lbVectorB2;
    private JLabel lbVectorB3;
    private JLabel lbVectorB4;
    private JLabel lbVectorB5;
    private JTextField tfVectorB1;
    private JTextField tfVectorB2;
    private JTextField tfVectorB3;
    private JTextField tfVectorB4;
    private JTextField tfVectorB5;
    private JButton btAceptarB;

    public DialogoIngresarDatosB()
    {
        lbTitulo = new JLabel("Ingresar Datos Vector B", JLabel.CENTER);
        lbTitulo.setFont(new Font("Arial", Font.BOLD, 25));
        lbTitulo.setBounds(10,10,300,20);
        add(lbTitulo);

        lbVectorB1 = new JLabel("B.1 = ", JLabel.RIGHT);
        lbVectorB1.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorB1.setBounds(10, 50, 140, 20);
        add(lbVectorB1);

        lbVectorB2 = new JLabel("B.2 = ", JLabel.RIGHT);
        lbVectorB2.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorB2.setBounds(10, 80, 140, 20);
        add(lbVectorB2);

        lbVectorB3 = new JLabel("B.3 = ", JLabel.RIGHT);
        lbVectorB3.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorB3.setBounds(10, 110, 140, 20);
        add(lbVectorB3);

        lbVectorB4 = new JLabel("B.4 = ", JLabel.RIGHT);
        lbVectorB4.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorB4.setBounds(10, 140, 140, 20);
        add(lbVectorB4);

        lbVectorB5 = new JLabel("B.5 = ", JLabel.RIGHT);
        lbVectorB5.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorB5.setBounds(10, 170, 140, 20);
        add(lbVectorB5);

        tfVectorB1 = new JTextField();
        tfVectorB1.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorB1.setBounds(150,50,100,25);
        add(tfVectorB1);

        tfVectorB2 = new JTextField();
        tfVectorB2.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorB2.setBounds(150,80,100,25);
        add(tfVectorB2);

        tfVectorB3 = new JTextField();
        tfVectorB3.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorB3.setBounds(150,110,100,25);
        add(tfVectorB3);

        tfVectorB4 = new JTextField();
        tfVectorB4.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorB4.setBounds(150,140,100,25);
        add(tfVectorB4);

        tfVectorB5 = new JTextField();
        tfVectorB5.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorB5.setBounds(150,170,100,25);
        add(tfVectorB5);
        
        btAceptarB = new JButton("Aceptar");
        btAceptarB.setBounds(150, 280, 260, 25);
        btAceptarB.setActionCommand("aceptarB");
        add(btAceptarB);

        setLayout(null);
        setTitle("Vector B");
        setSize(500,500);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
    }

    public String getVectorB1()
    {
        return tfVectorB1.getText();
    }

    public String getVectorB2()
    {
        return tfVectorB2.getText();
    }

    public String getVectorB3()
    {
        return tfVectorB3.getText();
    }

    public String getVectorB4()
    {
        return tfVectorB4.getText();
    }

    public String getVectorB5()
    {
        return tfVectorB5.getText();
    }

    public void agregarOyentesBotones(ActionListener pAL)
    {
        btAceptarB.addActionListener(pAL);
    }

    public void cerrarDialogoB()
    {
        this.dispose();
    }
}

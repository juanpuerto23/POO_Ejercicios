package Fuente.Vista;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

public class DialogoIngresarDatosA extends JDialog
{
    private JLabel lbTitulo;
    private JLabel lbVectorA1;
    private JLabel lbVectorA2;
    private JLabel lbVectorA3;
    private JLabel lbVectorA4;
    private JLabel lbVectorA5;
    private JTextField tfVectorA1;
    private JTextField tfVectorA2;
    private JTextField tfVectorA3;
    private JTextField tfVectorA4;
    private JTextField tfVectorA5;
    private JButton btAceptar;

    public DialogoIngresarDatosA()
    {
        lbTitulo = new JLabel("Ingresar Datos Vector A", JLabel.CENTER);
        lbTitulo.setFont(new Font("Arial", Font.BOLD, 25));
        lbTitulo.setBounds(10,10,300,20);
        add(lbTitulo);

        lbVectorA1 = new JLabel("A.1 = ", JLabel.RIGHT);
        lbVectorA1.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorA1.setBounds(10, 50, 140, 20);
        add(lbVectorA1);

        lbVectorA2 = new JLabel("A.2 = ", JLabel.RIGHT);
        lbVectorA2.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorA2.setBounds(10, 80, 140, 20);
        add(lbVectorA2);

        lbVectorA3 = new JLabel("A.3 = ", JLabel.RIGHT);
        lbVectorA3.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorA3.setBounds(10, 110, 140, 20);
        add(lbVectorA3);

        lbVectorA4 = new JLabel("A.4 = ", JLabel.RIGHT);
        lbVectorA4.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorA4.setBounds(10, 140, 140, 20);
        add(lbVectorA4);

        lbVectorA5 = new JLabel("A.5 = ", JLabel.RIGHT);
        lbVectorA5.setFont(new Font("Arial", Font.BOLD, 25));
        lbVectorA5.setBounds(10, 170, 140, 20);
        add(lbVectorA5);

        tfVectorA1 = new JTextField();
        tfVectorA1.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorA1.setBounds(150,50,100,25);
        add(tfVectorA1);

        tfVectorA2 = new JTextField();
        tfVectorA2.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorA2.setBounds(150,80,100,25);
        add(tfVectorA2);

        tfVectorA3 = new JTextField();
        tfVectorA3.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorA3.setBounds(150,110,100,25);
        add(tfVectorA3);

        tfVectorA4 = new JTextField();
        tfVectorA4.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorA4.setBounds(150,140,100,25);
        add(tfVectorA4);

        tfVectorA5 = new JTextField();
        tfVectorA5.setFont(new Font("Arial", Font.BOLD, 25));
        tfVectorA5.setBounds(150,170,100,25);
        add(tfVectorA5);
        
        btAceptar = new JButton("Aceptar");
        btAceptar.setBounds(150, 280, 260, 25);
        btAceptar.setActionCommand("aceptarA");
        add(btAceptar);

        setLayout(null);
        setTitle("Vector A");
        setSize(500,500);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
    }

    public String getVectorA1()
    {
        return tfVectorA1.getText();
    }

    public String getVectorA2()
    {
        return tfVectorA2.getText();
    }

    public String getVectorA3()
    {
        return tfVectorA3.getText();
    }

    public String getVectorA4()
    {
        return tfVectorA4.getText();
    }

    public String getVectorA5()
    {
        return tfVectorA5.getText();
    }

    public void agregarOyentesBotones(ActionListener pAL)
    {
        btAceptar.addActionListener(pAL);
    }

    public void cerrarDialogoA()
    {
        this.dispose();
    }
}

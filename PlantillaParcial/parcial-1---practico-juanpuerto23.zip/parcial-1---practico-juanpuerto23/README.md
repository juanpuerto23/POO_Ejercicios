[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-8d59dc4de5201274e310e4c54b9627a8934c3b88527886e3b421487c677d23eb.svg)](https://classroom.github.com/a/ijc13kaZ)

# Parcial 1 POO - Parte Práctica

Haciendo uso del patrón de diseño MVC, resuelva el siguiente problema.  Realice el correspondiente diagrama de clase para la clase del paquete modelo e inclúyalo en el README del repositorio.

Se requiere crear un programa que lea 5 números y los almacene en un vector llamado A, y otros 5 números en un vector llamado B, y que determine cuántos números de A se encuentran en B, creando un nuevo vector C para almacenar esos números comunes.

# Diseño

## Diagrama de clases
![Diagrama de clases](diagrama.png "Diagrama de clases")
